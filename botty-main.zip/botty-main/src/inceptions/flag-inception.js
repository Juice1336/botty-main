class Flag {

}