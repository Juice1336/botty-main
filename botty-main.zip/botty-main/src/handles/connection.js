const Authorization = require('../core/authorization');
let onConnectionHandle = Authorization.validate

module.exports = onConnectionHandle;