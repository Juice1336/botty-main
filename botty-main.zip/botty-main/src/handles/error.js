let onErrorHandle = function (ws) {
    console.log(ws)
}

module.exports = onErrorHandle;